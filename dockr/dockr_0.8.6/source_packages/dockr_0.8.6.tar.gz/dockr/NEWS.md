# dockr 0.8.5

* First submission to CRAN.
